package Adapter;

/**
 * Created by merna.shenda on 5/22/2018.
 */

public interface OnLoadMoreListener {
    void onLoadMore();
}
