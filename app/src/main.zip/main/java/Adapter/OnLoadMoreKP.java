package Adapter;

/**
 * Created by merna.shenda on 6/22/2018.
 */

public interface OnLoadMoreKP {
    void onLoadMoreKP();
}
